
CREATE TABLE Companias (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Direccion varchar(255) NOT NULL,
    Telefono varchar(255) NOT NULL
);

CREATE TABLE Departamentos (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Compania_ID int NOT NULL,
    FOREIGN KEY (Compania_ID) REFERENCES Companias(ID)
);

CREATE TABLE Empleados (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Departamento_ID int NOT NULL,
    FOREIGN KEY (Departamento_ID) REFERENCES Departamentos(ID)
);

CREATE TABLE Proveedores (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Direccion varchar(255) NOT NULL,
    Telefono varchar(255) NOT NULL
);

CREATE TABLE Tipos_de_Equipos (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Descripcion varchar(255) NOT NULL
);

CREATE TABLE Equipos (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Marca varchar(255) NOT NULL,
    Modelo varchar(255) NOT NULL,
    Fecha_Compra date NOT NULL,
    Memoria_RAM int NOT NULL,
    Memoria_Disco int NOT NULL,
    Tipo_ID int NOT NULL,
    Proveedor_ID int NOT NULL,
    FOREIGN KEY (Tipo_ID) REFERENCES Tipos_de_Equipos(ID),
    FOREIGN KEY (Proveedor_ID) REFERENCES Proveedores(ID)
);

CREATE TABLE Bodegas (
    ID int AUTO_INCREMENT PRIMARY KEY,
    Nombre varchar(255) NOT NULL,
    Ubicacion varchar(255) NOT NULL
);



CREATE TABLE Asignaciones (
ID int PRIMARY KEY AUTO_INCREMENT,
Empleado_ID int NOT NULL,
Equipo_ID int NOT NULL,
Bodega_ID int NOT NULL,
Fecha_Asignacion date NOT NULL,
FOREIGN KEY (Empleado_ID) REFERENCES Empleados(ID),
FOREIGN KEY (Equipo_ID) REFERENCES Equipos(ID),
FOREIGN KEY (Bodega_ID) REFERENCES Bodegas(ID)
);

INSERT INTO Companias ( Nombre, Direccion, Telefono)
VALUES ( 'Compañía 1', 'Dirección 1', 'Teléfono 1');

INSERT INTO Departamentos ( Nombre, Compania_ID)
VALUES ( 'Departamento 1', 1);

INSERT INTO Empleados ( Nombre, Departamento_ID)
VALUES ( 'Empleado 1', 1);

INSERT INTO Proveedores ( Nombre, Direccion, Telefono)
VALUES ( 'Proveedor 1', 'Dirección 1', 'Teléfono 1');

INSERT INTO Tipos_de_Equipos ( Nombre, Descripcion)
VALUES ( 'Tipo 1', 'Descripción 1');

INSERT INTO Equipos ( Nombre, Marca, Modelo, Fecha_Compra, Memoria_RAM, Memoria_Disco, Tipo_ID, Proveedor_ID)
VALUES ( 'Equipo 1', 'Marca 1', 'Modelo 1', '2022-01-01', 8, 128, 1, 1);

INSERT INTO Bodegas ( Nombre, Ubicacion)
VALUES ( 'Bodega 1', 'Ubicación 1');

INSERT INTO Asignaciones ( Empleado_ID, Equipo_ID, Bodega_ID, Fecha_Asignacion)
VALUES ( 1, 1, 1, '2022-01-01');


select  * from asignaciones;